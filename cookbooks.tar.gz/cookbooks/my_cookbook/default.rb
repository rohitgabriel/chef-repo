default['my_cookbook']['message'] = 'hello world!'
