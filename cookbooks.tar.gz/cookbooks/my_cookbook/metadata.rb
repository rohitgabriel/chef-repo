name 'my_cookbook'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures my_cookbook'
long_description 'Installs/Configures my_cookbook'
version '0.1.0'
depends "chef-client"
depends "apt"
depends "ntp"
