default['my_cookbook']['message'] = "#{node['my_cookbook']['hi']} #{node['my_cookbook']['world']}!"
default['my_cookbook']['xname'] = 'Rohit'