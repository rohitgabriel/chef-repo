# my_ntp

TODO: Enter the cookbook description here.

