name             'my_apache2_cookbook'
maintainer       'The Authors'
maintainer_email 'you@example.com'
license          'all_rights'
description      'Installs/Configures my_apache2_cookbook'
long_description 'Installs/Configures my_apache2_cookbook'
version          '0.1.0'

