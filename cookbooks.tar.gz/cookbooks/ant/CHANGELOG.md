## v1.0.2:

### Bug

- [COOK-2943]: Ant cookbook has foodcritic failures

## v1.0.0:

* [COOK-1711] - Refactored - separate recipes for source vs package
  install, LWRP for ant libraries, still backwards compatible (package
  default installation as previous versions)
