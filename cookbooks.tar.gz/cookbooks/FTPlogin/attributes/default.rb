default['FTPlogin']['binaryhost'] = '192.168.1.7'
default['FTPlogin']['ftploginuser'] = 'ftplogin'
default['FTPlogin']['binarydir'] = '/opt/ibm/HTTPServer/docroot'
default['FTPlogin']['ftploginpwd'] = 'W1zplay11'